from __future__ import annotations

from models import Component, SafetyGoal, SafetyRequirement

from .base import Agent, as_conf, as_str, dumps, items

LEVELS = ("FSR", "TSR", "SSR")


class SafetyRequirementAgent(Agent):
    """FSR -> TSR -> SSR for all of a component's safety goals in one call.

    Requirement ASIL is inherited from the parent goal in code (the model cannot silently lower
    it); IDs and parent links are assigned here so they are always unique and consistent.
    """

    def generate(
        self, comp: Component, idx: int, goals: list[SafetyGoal]
    ) -> list[SafetyRequirement]:
        if not goals:
            return []
        goal_in = [{"id": g.id, "goal": g.text, "asil": g.asil, "safe_state": g.safe_state,
                    "ftti_ms": g.ftti_ms} for g in goals]
        data = self.ask(
            "For each safety goal derive requirements: >=1 FSR (functional safety concept), "
            ">=1 TSR (technical, ECU/system level) and >=1 SSR (software, this component only; must "
            "name a real runnable/port from the component).\n"
            'Schema: {"requirements":[{"goal_id":str,"level":"FSR|TSR|SSR","text":str,'
            '"mechanism":str,"fault_reaction":str,"verification_method":str,"rationale":str,'
            '"confidence":0..1}]}\n'
            f"Component: {dumps(comp.brief())}\nSafety goals: {dumps(goal_in)}"
        )
        by_goal = {g.id: g for g in goals}
        counters = {lvl: 0 for lvl in LEVELS}
        last: dict[tuple[str, str], str] = {}  # (goal, level) -> id of most recent requirement
        out: list[SafetyRequirement] = []

        # Process FSR before TSR before SSR so parent links always resolve.
        rows = [r for r in items(data, "requirements") if as_str(r.get("goal_id")) in by_goal]
        rows.sort(key=lambda r: LEVELS.index(as_str(r.get("level")).upper())
                  if as_str(r.get("level")).upper() in LEVELS else 99)
        for r in rows:
            level = as_str(r.get("level")).upper()
            if level not in LEVELS or not as_str(r.get("text")):
                continue
            goal = by_goal[as_str(r.get("goal_id"))]
            counters[level] += 1
            rid = f"{level}-{idx:02d}-{counters[level]:02d}"
            parent = goal.id if level == "FSR" else last.get(
                (goal.id, "FSR" if level == "TSR" else "TSR")) or last.get((goal.id, "FSR"), goal.id)
            last[(goal.id, level)] = rid
            out.append(SafetyRequirement(
                id=rid, level=level, parent_id=parent, swc=comp.name, text=as_str(r.get("text")),
                asil=goal.asil, mechanism=as_str(r.get("mechanism")),
                fault_reaction=as_str(r.get("fault_reaction")),
                verification_method=as_str(r.get("verification_method")),
                rationale=as_str(r.get("rationale")), confidence=as_conf(r.get("confidence")),
            ))
        return out
