from __future__ import annotations

from models import Component, SafetyRequirement, TestCase

from .base import Agent, as_list, as_str, dumps, items

KINDS = {"functional", "negative", "boundary", "fault-injection"}


class TestCaseAgent(Agent):
    __test__ = False  # not a pytest class

    def generate(
        self, comp: Component, idx: int, requirements: list[SafetyRequirement]
    ) -> list[TestCase]:
        ssrs = [r for r in requirements if r.level == "SSR"]
        if not ssrs:
            return []
        req_in = [{"id": r.id, "asil": r.asil, "text": r.text, "reaction": r.fault_reaction}
                  for r in ssrs]
        data = self.ask(
            "Write verification test cases for these software safety requirements: at least one "
            "functional and one negative/fault-injection case per requirement; add a boundary case "
            "where a numeric limit (time, threshold) is stated.\n"
            'Schema: {"tests":[{"requirement_id":str,"kind":"functional|negative|boundary|'
            'fault-injection","objective":str,"preconditions":str,"steps":[str],"expected":str}]}\n'
            f"Component: {dumps(comp.brief())}\nRequirements: {dumps(req_in)}"
        )
        valid = {r.id for r in ssrs}
        out: list[TestCase] = []
        for t in items(data, "tests"):
            rid = as_str(t.get("requirement_id"))
            if rid not in valid:
                continue  # hallucinated link: drop rather than pollute the trace matrix
            kind = as_str(t.get("kind"), "functional").lower()
            out.append(TestCase(
                id=f"TC-{idx:02d}-{len(out) + 1:02d}", requirement_id=rid,
                kind=kind if kind in KINDS else "functional",
                objective=as_str(t.get("objective")), preconditions=as_str(t.get("preconditions")),
                steps=[as_str(s) for s in as_list(t.get("steps")) if as_str(s)],
                expected=as_str(t.get("expected")),
            ))
        return out
