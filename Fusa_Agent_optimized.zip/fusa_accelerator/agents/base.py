"""Shared agent plumbing: prompt contract, tolerant coercion of LLM output."""
from __future__ import annotations

import json
from typing import Any

from llm import LLM

SYSTEM = (
    "You are an ISO 26262 functional safety engineer. Respond with ONE valid JSON object only, "
    "matching the requested schema exactly. No prose, no markdown. Be specific to the component "
    "provided; never invent ports, runnables or signals that are not listed."
)


def dumps(obj: Any) -> str:
    return json.dumps(obj, separators=(",", ":"), ensure_ascii=False)  # compact => fewer tokens


def as_str(v: Any, default: str = "") -> str:
    return default if v is None else str(v).strip()


def as_float(v: Any, default: float | None = None) -> float | None:
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def as_conf(v: Any) -> float:
    f = as_float(v, 0.5)
    return min(1.0, max(0.0, f))


def as_list(v: Any) -> list:
    if v is None:
        return []
    return v if isinstance(v, list) else [v]


def items(payload: Any, key: str) -> list[dict]:
    """Accept {'key': [...]} or a bare list; drop anything that is not an object."""
    if isinstance(payload, dict):
        payload = payload.get(key, [])
    return [x for x in as_list(payload) if isinstance(x, dict)]


class Agent:
    def __init__(self, llm: LLM):
        self.llm = llm

    def ask(self, user: str) -> Any:
        return self.llm.complete_json(SYSTEM, user)
