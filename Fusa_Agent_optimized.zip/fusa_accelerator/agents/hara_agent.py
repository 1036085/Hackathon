from __future__ import annotations

from models import Component, Hazard, Requirement, SafetyGoal
from rules import determine_asil

from .base import Agent, as_conf, as_float, as_str, dumps, items


def _rating(v, prefix: str) -> str:
    s = as_str(v).upper().replace(" ", "")
    return s if s.startswith(prefix) else f"{prefix}{s}" if s.isdigit() else f"{prefix}0"


class HaraAgent(Agent):
    """Hazards + S/E/C ratings + safety goals in ONE call.

    ASIL is computed from S/E/C by the rule engine, never trusted from the model. The original
    pipeline made 6 sequential LLM calls per SWC and hard-coded S3/E4/C2 for every component.
    """

    def generate(
        self, comp: Component, idx: int, requirements: list[Requirement]
    ) -> tuple[list[Hazard], list[SafetyGoal]]:
        reqs = [{"id": r.id, "text": r.text[:200]} for r in requirements[:15]]
        data = self.ask(
            "Perform an ISO 26262-3 HARA for this software component. Identify 1-4 malfunctioning "
            "behaviours that could violate safety. For each, rate Severity S0-S3, Exposure E0-E4, "
            "Controllability C0-C3 and, if the result is not QM, give a safety goal.\n"
            'Schema: {"hazards":[{"function":str,"malfunction":str,"hazard":str,"situation":str,'
            '"severity":"S0..S3","exposure":"E0..E4","controllability":"C0..C3","rationale":str,'
            '"confidence":0..1,"safety_goal":str,"safe_state":str,"ftti_ms":number}]}\n'
            f"Component: {dumps(comp.brief())}\nRelated requirements: {dumps(reqs)}"
        )
        hazards: list[Hazard] = []
        goals: list[SafetyGoal] = []
        for n, h in enumerate(items(data, "hazards"), 1):
            s, e, c = (_rating(h.get("severity"), "S"), _rating(h.get("exposure"), "E"),
                       _rating(h.get("controllability"), "C"))
            asil = determine_asil(s, e, c)
            hid = f"HZ-{idx:02d}-{n:02d}"
            hazards.append(Hazard(
                id=hid, swc=comp.name,
                function=as_str(h.get("function")), malfunction=as_str(h.get("malfunction")),
                hazard=as_str(h.get("hazard")), situation=as_str(h.get("situation")),
                severity=s, exposure=e, controllability=c, asil=asil,
                rationale=as_str(h.get("rationale")), confidence=as_conf(h.get("confidence")),
            ))
            goal_text = as_str(h.get("safety_goal"))
            if asil != "QM" and goal_text:
                goals.append(SafetyGoal(
                    id=f"SG-{idx:02d}-{n:02d}", hazard_id=hid, text=goal_text, asil=asil,
                    safe_state=as_str(h.get("safe_state")), ftti_ms=as_float(h.get("ftti_ms")),
                ))
        return hazards, goals
