from __future__ import annotations

from models import Component, Requirement

from .base import Agent, as_str, dumps


class ItemDefinitionAgent(Agent):
    """One call per project (not per SWC). Returns Markdown for display/export."""

    def generate(self, requirements: list[Requirement], components: list[Component]) -> str:
        reqs = [{"id": r.id, "text": r.text[:240]} for r in requirements[:25]]
        comps = [c.brief() for c in components[:40]]
        data = self.ask(
            "Write an ISO 26262-3 Item Definition.\n"
            'Schema: {"item_name":str,"purpose":str,"operational_modes":[str],'
            '"interfaces":[str],"boundary":str,"dependencies":[str]}\n'
            f"Requirements: {dumps(reqs)}\nComponents: {dumps(comps)}"
        )
        if not isinstance(data, dict):
            return ""

        def bullets(key: str) -> str:
            vals = data.get(key) or []
            return "\n".join(f"- {as_str(v)}" for v in (vals if isinstance(vals, list) else [vals]))

        return (
            f"**Item:** {as_str(data.get('item_name'))}\n\n"
            f"**Purpose:** {as_str(data.get('purpose'))}\n\n"
            f"**Operational modes:**\n{bullets('operational_modes')}\n\n"
            f"**Interfaces:**\n{bullets('interfaces')}\n\n"
            f"**Boundary:** {as_str(data.get('boundary'))}\n\n"
            f"**Dependencies:**\n{bullets('dependencies')}"
        )
