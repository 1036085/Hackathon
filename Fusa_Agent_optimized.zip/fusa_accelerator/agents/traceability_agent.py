from __future__ import annotations

from models import SwcResult


class TraceabilityAgent:
    """Deterministic traceability: Hazard -> Goal -> FSR -> TSR -> SSR -> Test.

    Links are the IDs assigned by the other agents, so the chain can be verified
    mechanically. (The original stuffed whole LLM text blobs into one row, which was neither
    machine-checkable nor exportable.)
    """

    COLUMNS = ["SWC", "Hazard", "ASIL", "Safety Goal", "FSR", "TSR", "SSR", "Test Case", "Gap"]

    def build(self, results: list[SwcResult]) -> list[dict]:
        rows: list[dict] = []
        for res in results:
            req = {r.id: r for r in res.requirements}
            tests_for: dict[str, list[str]] = {}
            for t in res.tests:
                tests_for.setdefault(t.requirement_id, []).append(t.id)
            goals_for: dict[str, list] = {}
            for g in res.goals:
                goals_for.setdefault(g.hazard_id, []).append(g)

            def ancestors(rid: str) -> dict[str, str]:
                chain: dict[str, str] = {}
                cur = req.get(rid)
                while cur is not None:
                    chain[cur.level] = cur.id
                    cur = req.get(cur.parent_id)
                return chain

            for h in res.hazards:
                goals = goals_for.get(h.id, [])
                if not goals:
                    rows.append(self._row(res.swc, h.id, h.asil, "", {}, [],
                                          "no safety goal" if h.asil != "QM" else ""))
                for g in goals:
                    ssrs = [r for r in res.requirements
                            if r.level == "SSR" and self._goal_of(r, req) == g.id]
                    if not ssrs:
                        fsrs = [r.id for r in res.requirements if r.parent_id == g.id]
                        rows.append(self._row(res.swc, h.id, h.asil, g.id,
                                              {"FSR": ", ".join(fsrs)}, [], "no SSR"))
                    for s in ssrs:
                        rows.append(self._row(res.swc, h.id, h.asil, g.id, ancestors(s.id),
                                              tests_for.get(s.id, []),
                                              "" if tests_for.get(s.id) else "no test case"))
        return rows

    @staticmethod
    def _goal_of(r, req) -> str:
        cur = r
        while cur is not None and cur.parent_id in req:
            cur = req[cur.parent_id]
        return cur.parent_id if cur is not None else ""

    @staticmethod
    def _row(swc, hazard, asil, goal, chain, tests, gap) -> dict:
        return {
            "SWC": swc, "Hazard": hazard, "ASIL": asil, "Safety Goal": goal,
            "FSR": chain.get("FSR", ""), "TSR": chain.get("TSR", ""), "SSR": chain.get("SSR", ""),
            "Test Case": ", ".join(tests), "Gap": gap,
        }
