"""ISO 26262-3 Table 4 ASIL determination. Deterministic: the LLM only proposes S/E/C."""
from __future__ import annotations

import re

ASIL_ORDER = {"QM": 0, "ASIL-A": 1, "ASIL-B": 2, "ASIL-C": 3, "ASIL-D": 4}
_SUM_TO_ASIL = {10: "ASIL-D", 9: "ASIL-C", 8: "ASIL-B", 7: "ASIL-A"}


def _level(value: str, prefix: str, maximum: int) -> int | None:
    m = re.fullmatch(rf"\s*{prefix}\s*([0-9])\s*", str(value or ""), re.I)
    if not m or int(m.group(1)) > maximum:
        return None
    return int(m.group(1))


def normalize_asil(value: str | None) -> str:
    """'B', 'asil b', 'ASIL-B' -> 'ASIL-B'; anything unknown -> 'QM'."""
    v = re.sub(r"[^A-Za-z]", "", str(value or "")).upper().replace("ASIL", "")
    return f"ASIL-{v}" if v in {"A", "B", "C", "D"} else "QM"


def determine_asil(severity: str, exposure: str, controllability: str) -> str:
    """Table 4 equals: S+E+C = 10 -> D, 9 -> C, 8 -> B, 7 -> A, else QM.

    Any S0/E0/C0 (or an invalid rating) is QM. The original lookup only had 6 of the 36
    meaningful combinations and returned QM for the rest -- e.g. (S3,E3,C2) = ASIL-B was lost.
    """
    s, e, c = _level(severity, "S", 3), _level(exposure, "E", 4), _level(controllability, "C", 3)
    if None in (s, e, c) or 0 in (s, e, c):
        return "QM"
    return _SUM_TO_ASIL.get(s + e + c, "QM")


def max_asil(*values: str) -> str:
    return max((normalize_asil(v) for v in values), key=ASIL_ORDER.__getitem__, default="QM")


def asil_at_least(value: str, minimum: str) -> bool:
    return ASIL_ORDER[normalize_asil(value)] >= ASIL_ORDER[normalize_asil(minimum)]
