"""Deterministic Rule Engine: structural, safety and documentation checks. No LLM involved."""
from __future__ import annotations

import re
from collections import defaultdict

from models import Component, Requirement, SwcResult

from .asil_rules import ASIL_ORDER, asil_at_least, normalize_asil


def _norm(text: str) -> str:
    return re.sub(r"\W+", " ", text.lower()).strip()


class DeterministicEngine:
    # ---- structural validation (pre-LLM) ------------------------------------------------
    def validate_component(self, c: Component) -> list[str]:
        issues = []
        if not c.ports:
            issues.append(f"{c.name}: no ports defined")
        if not c.runnables:
            issues.append(f"{c.name}: no runnables defined")
        for p in c.ports:
            if not p.interface:
                issues.append(f"{c.name}: port '{p.name}' has no interface")
        for r in c.runnables:
            if not r.events:
                issues.append(f"{c.name}: runnable '{r.name}' has no triggering event")
        if not any(p.direction in ("P", "PR") for p in c.ports) and c.ports:
            issues.append(f"{c.name}: no provided port -- no output to protect?")
        return issues

    def validate_all(
        self,
        components: list[Component],
        requirements: list[Requirement] | None = None,
        allocation: dict[str, str] | None = None,
    ) -> list[str]:
        """Project-level checks: duplicate SWCs/requirements, unallocated requirements."""
        findings: list[str] = []
        if not components:
            findings.append("No software components found in the inputs")
        names = [c.name for c in components]
        for n in sorted({n for n in names if names.count(n) > 1}):
            findings.append(f"Duplicate SWC name: {n}")

        if requirements:
            findings += self.check_duplicate_requirements(requirements)
            if allocation is not None:
                findings += [
                    f"Requirement {r.id} is not allocated to any SWC"
                    for r in requirements if r.id not in allocation
                ]
        return findings

    @staticmethod
    def check_duplicate_requirements(reqs: list[Requirement]) -> list[str]:
        by_text: dict[str, list[str]] = defaultdict(list)
        for r in reqs:
            by_text[_norm(r.text)].append(r.id)
        return [f"Duplicate requirement text: {', '.join(ids)}"
                for ids in by_text.values() if len(ids) > 1]

    # ---- safety / documentation validation (post-LLM) -----------------------------------
    def validate_result(self, res: SwcResult, confidence_threshold: float = 0.7) -> list[str]:
        issues: list[str] = []
        goal_by_id = {g.id: g for g in res.goals}
        hazard_ids = {h.id for h in res.hazards}
        req_ids = {r.id for r in res.requirements}

        # duplicate safety goals
        seen: dict[str, str] = {}
        for g in res.goals:
            key = _norm(g.text)
            if key in seen:
                issues.append(f"Duplicate safety goal: {g.id} == {seen[key]}")
            seen[key] = g.id

        # ASIL consistency: no requirement may carry a lower ASIL than the goal it derives from
        # (decomposition would have to be explicit; flag it instead of guessing).
        for r in res.requirements:
            goal = goal_by_id.get(r.parent_id)
            if goal is None:
                continue
            if not asil_at_least(r.asil, goal.asil):
                issues.append(
                    f"ASIL inconsistency: {r.id} is {normalize_asil(r.asil)} but goal "
                    f"{goal.id} is {goal.asil} (no decomposition declared)"
                )

        # traceability chain: hazard -> goal -> requirement -> test
        for g in res.goals:
            if g.hazard_id not in hazard_ids:
                issues.append(f"{g.id}: references unknown hazard '{g.hazard_id}'")
            if not any(r.parent_id == g.id for r in res.requirements):
                issues.append(f"{g.id}: no safety requirement derived from this goal")
        for h in res.hazards:
            if h.asil != "QM" and not any(g.hazard_id == h.id for g in res.goals):
                issues.append(f"{h.id}: {h.asil} hazard has no safety goal")
        tested = {t.requirement_id for t in res.tests}
        for r in res.requirements:
            if r.level == "SSR" and r.id not in tested:
                issues.append(f"{r.id}: no verification test case")
        for t in res.tests:
            if t.requirement_id not in req_ids:
                issues.append(f"{t.id}: references unknown requirement '{t.requirement_id}'")

        # empty template fields + low confidence
        for r in res.requirements:
            if not r.text.strip():
                issues.append(f"{r.id}: empty requirement text")
            if not r.verification_method.strip():
                issues.append(f"{r.id}: empty verification method")
            if r.confidence < confidence_threshold:
                issues.append(f"{r.id}: low model confidence ({r.confidence:.2f}) -- review")
        for h in res.hazards:
            if h.confidence < confidence_threshold:
                issues.append(f"{h.id}: low model confidence ({h.confidence:.2f}) -- review")

        # duplicate IDs
        for label, ids in (("hazard", [h.id for h in res.hazards]),
                           ("requirement", [r.id for r in res.requirements]),
                           ("test case", [t.id for t in res.tests])):
            for i in sorted({i for i in ids if ids.count(i) > 1}):
                issues.append(f"Duplicate {label} ID: {i}")
        return issues
