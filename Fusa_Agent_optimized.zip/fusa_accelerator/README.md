# AI-Powered Automotive Functional Safety (FuSa) Engineering Accelerator

> Agentic AI-assisted ISO 26262 HARA, Safety Requirement, Traceability, and Verification Test Generation Platform

## Overview

Functional Safety (FuSa) engineering in automotive projects requires extensive manual analysis of:

- AUTOSAR ARXML files
- Software Component (SWC) specifications
- ECU Extracts
- Functional Requirements
- Existing Safety Documents
- ISO 26262 Work Products

The process is often repetitive, time-consuming, and prone to inconsistencies.

This project introduces an AI-powered engineering accelerator that combines deterministic engineering rules with Large Language Models (LLMs) to automatically generate:

- HARA Worksheets
- Hazard Candidates
- Safety Goals
- Technical Safety Requirements (TSR)
- Software Safety Requirements (SSR)
- Verification Test Cases
- Traceability Matrices
- Exportable Engineering Documents

---

# Architecture

```text
┌──────────────────────────────┐
│ Streamlit Frontend           │
│ Upload ARXML / SWC / ECU     │
└──────────────┬───────────────┘
               │
               ▼
┌──────────────────────────────┐
│ Parser Service               │
│                              │
│ • ARXML Parser               │
│ • ECU Extract Parser         │
│ • SWC Extractor              │
│ • XML Validation             │
└──────────────┬───────────────┘
               │
               ▼
┌──────────────────────────────┐
│ Deterministic Rule Engine    │
│                              │
│ • Missing Ports Check        │
│ • Missing Runnable Check     │
│ • ASIL Consistency Rules     │
│ • ISO Template Population    │
└──────────────┬───────────────┘
               │
               ▼
┌──────────────────────────────┐
│ AI Agent Layer               │
│                              │
│ Qwen3.8-27B-FP8             │
│ Ollama + vLLM               │
│                              │
│ Agents:                     │
│ • HARA Agent                │
│ • Safety Requirement Agent  │
│ • Test Case Agent           │
│ • Traceability Agent        │
└──────────────┬───────────────┘
               │
               ▼
┌──────────────────────────────┐
│ Export Layer                 │
│                              │
│ • Excel                      │
│ • Word                       │
│ • CSV                        │
└──────────────────────────────┘
```

---

# System Workflow

```text
Engineering Inputs
      │
      ▼
ARXML / SWC / ECU Extract
      │
      ▼
Data Parsing & Validation
      │
      ▼
Deterministic Engineering Checks
      │
      ▼
AI Interpretation & Generation
      │
      ▼
Artifact Creation
      │
      ▼
Engineer Review & Approval
      │
      ▼
Excel / Word Export
```

---

# Technology Stack

## Frontend

- Streamlit

## Backend

- Python 3.13
- FastAPI (Optional Future Enhancement)

## AI Stack

### Primary LLM

**Qwen3.8-27B-FP8**

Model Source:

https://huggingface.co/Qwen/Qwen3.8-27B-FP8

### Inference Layer

- Ollama
- vLLM

### Decision / Routing Model

Cloudflare Clef Flash

https://huggingface.co/Cloudflare/clef-flash

---

# Project Structure

```text
fusa_accelerator/
├── app.py                  Streamlit frontend (review/approval gate, downloads)
├── run_cli.py              headless run
├── pipeline.py             orchestration (parallel per SWC, failure-isolated)
├── config.py               settings, all overridable via FUSA_* env vars
├── models.py               typed artefacts (Component, Hazard, SafetyGoal, ...)
├── parsers/                ARXML, ECU extract, SWC design doc, requirements, XML validation
├── rules/                  ISO 26262-3 ASIL table + deterministic engine
├── llm/                    Ollama / vLLM client: retries, JSON repair, disk cache
├── agents/                 HARA, Safety Requirement, Test Case, Traceability, Item Definition
├── exporters/              Excel (template-aware), Word, CSV
└── tests/                  pytest suite (fake LLM, no GPU needed)
```

## Configuration

| Env var | Default | Purpose |
|---|---|---|
| `FUSA_BACKEND` | `ollama` | `ollama` or `vllm` |
| `FUSA_MODEL` | `qwen3:27b` | model name on the server |
| `FUSA_OLLAMA_URL` / `FUSA_VLLM_URL` | `localhost:11434` / `localhost:8000/v1` | endpoints |
| `FUSA_MAX_WORKERS` | `4` | parallel SWC analyses (vLLM batches these) |
| `FUSA_THINK` | `0` | enable Qwen3 thinking mode (slower) |
| `FUSA_CONFIDENCE_THRESHOLD` | `0.70` | below this, items are flagged for review |

Run: `streamlit run app.py` · tests: `pytest` · headless: `python run_cli.py model.arxml reqs.docx`

---

# Core Components

## 1. Parser Layer

Responsible for extracting engineering information from:

- AUTOSAR ARXML
- ECU Extracts
- Existing Safety Documentation

### Extracted Information

- Software Components
- Ports
- Interfaces
- Signals
- Events
- Runnables
- Dependencies

Example:

```xml
<SW-COMPONENT-TYPE>
    <SHORT-NAME>AudioManager</SHORT-NAME>
</SW-COMPONENT-TYPE>
```

Parsed Output:

```json
{
  "swc": "AudioManager",
  "runnable": "ProcessAudio",
  "port": "SpeakerOutput"
}
```

---

## 2. Deterministic Rule Engine

Performs engineering validation before invoking AI.

### Current Rule Set

#### Structural Validation

- Missing SWCs
- Missing Ports
- Missing Interfaces
- Missing Runnables

#### Safety Validation

- ASIL Consistency
- Duplicate Safety Goals
- Duplicate Requirements

#### Documentation Validation

- Empty Template Fields
- Missing Traceability References

---

## 3. AI Agent Layer

### HARA Agent

Generates:

- Hazard Candidates
- Severity
- Exposure
- Controllability
- ASIL Recommendation

### Safety Requirement Agent

Generates:

- Technical Safety Requirements
- Software Safety Requirements

### Test Case Agent

Generates:

- Functional Safety Verification Tests
- Negative Scenarios
- Boundary Tests

### Traceability Agent

Creates links between:

```text
Hazard
   │
   ▼
Safety Goal
   │
   ▼
TSR
   │
   ▼
SSR
   │
   ▼
Test Case
```

---

# LLM Deployment Options

---

## Option 1 - Ollama Deployment

### Install Ollama

```bash
curl -fsSL https://ollama.com/install.sh | sh
```

### Pull Qwen Model

```bash
ollama pull qwen3:27b
```

### Start Ollama

```bash
ollama serve
```

### Verify Deployment

```bash
ollama run qwen3:27b
```

### Python Configuration

```python
OLLAMA_URL = "http://localhost:11434"

MODEL_NAME = "qwen3:27b"
```

---

## Option 2 - vLLM Deployment (Recommended)

vLLM provides:

- Faster Throughput
- Better GPU Utilization
- OpenAI-Compatible API
- Batch Inference Support

### Installation

```bash
pip install --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhosted.org vllm 
```
```bash
pip install vllm
```

### Start Server

```bash
python -m vllm.entrypoints.openai.api_server \
  --model Qwen/Qwen3.8-27B-FP8 \
  --tensor-parallel-size 1 \
  --gpu-memory-utilization 0.95
```

### Endpoint

```text
http://localhost:8000/v1/chat/completions
```

### Python Configuration

```python
VLLM_URL = "http://localhost:8000/v1/chat/completions"
```

---

# Sample Prompt

```text
You are an ISO 26262 Functional Safety Engineer.

Generate:

1. HARA Analysis
2. Technical Safety Requirements
3. Software Safety Requirements
4. Verification Test Cases

Component:
AudioManager

Runnable:
ProcessAudio

Port:
SpeakerOutput

Provide:
- Requirement ID
- ASIL
- Requirement Statement
- Rationale
- Verification Method
```

---

# Example AI Output

## Software Safety Requirement

```text
SSR-001

ASIL-B

The AudioManager SWC shall disable
SpeakerOutput within 100 ms upon
detection of invalid audio
processing conditions.
```

---

## Test Case

```text
TC-001

Objective:
Verify safe state transition.

Precondition:
System Operational

Steps:
1. Inject Audio Fault
2. Execute ProcessAudio()
3. Monitor SpeakerOutput

Expected Result:
SpeakerOutput disabled within 100 ms.
```

---

# Generated Deliverables

The platform generates:

## HARA Documents

- Hazard Worksheets
- Risk Assessment Tables

## Safety Requirements

- Safety Goals
- TSR
- SSR

## Verification Artifacts

- Verification Test Cases
- Review Checklists

## Traceability

- Hazard-to-Test Mapping
- Requirement Traceability Matrix

---

# Export Formats

| Artifact | Format |
|-----------|----------|
| HARA Worksheet | Excel |
| TSR | Word |
| SSR | Word |
| Traceability Matrix | Excel |
| Verification Tests | Excel |
| Review Report | PDF |

---

# MVP Scope

## Phase 1

Input:

- Sample SWC
- Sample ARXML

Output:

- Hazard Candidates
- TSR
- SSR
- Verification Test Cases

---

## Phase 2

Add:

- ECU Extract Parsing
- Multiple SWCs
- Traceability Automation

---

## Phase 3

Add:

- RAG with ISO 26262
- Engineering Knowledge Base
- Similar Project Retrieval

---

# Hardware Requirements

## Minimum

| Component | Requirement |
|-----------|-------------|
| RAM | 16 GB |
| CPU | Intel i5 / Ryzen 5 |
| Storage | 50 GB SSD |
| OS | Windows 10/11 64-bit |

## Recommended

| Component | Requirement |
|-----------|-------------|
| RAM | 32 GB |
| CPU | Intel i7 / Ryzen 7 |
| GPU | NVIDIA GPU |
| Storage | 100 GB SSD |
| OS | Windows 11 |

---

# Expected Benefits

✅ Reduced Manual Analysis Effort

✅ Faster Requirement Generation

✅ Improved Consistency

✅ Improved Traceability

✅ Reusable Engineering Templates

✅ Accelerated ISO 26262 Compliance Activities

---

# Future Enhancements

- LangGraph Multi-Agent Workflow
- ISO 26262 RAG Integration
- FMEA Generation
- Auto Review Assistant
- Requirement Quality Checker
- ASPICE Compliance Checks
- Human Approval Workflow
- Enterprise Integration (PLM / DOORS)

---

# Hackathon Value Proposition

**FuSa Copilot**

Upload AUTOSAR ARXML and engineering specifications, then automatically generate:

- HARA Analysis
- Hazard Candidates
- Safety Goals
- TSRs
- SSRs
- Verification Test Cases
- Traceability Matrices

using a hybrid architecture combining deterministic engineering rules and Qwen3-powered AI reasoning.

**Goal:** Reduce Functional Safety engineering effort while improving consistency, completeness, and traceability.