"""Functional requirement table parser (.docx)."""
from __future__ import annotations

import re
from typing import IO, Union

from docx import Document

from models import Requirement

# The original hard-coded (ACC|AEB|ARB)-FR-n, which silently dropped every other project's IDs.
DEFAULT_ID_RE = re.compile(r"^[A-Za-z][A-Za-z0-9]*(?:-[A-Za-z0-9]+)*-?\d+$")


class RequirementParser:
    def __init__(self, id_pattern: re.Pattern[str] = DEFAULT_ID_RE):
        self.id_pattern = id_pattern

    @staticmethod
    def _col(headers: list[str], *names: str) -> int | None:
        low = [h.lower() for h in headers]
        for n in names:
            for i, h in enumerate(low):
                if h == n or n in h:
                    return i
        return None

    def parse(self, source: Union[str, IO[bytes]]) -> list[Requirement]:
        doc = Document(source)
        out: list[Requirement] = []
        seen: set[str] = set()
        for table in doc.tables:
            if len(table.rows) < 2:
                continue
            headers = [c.text.strip() for c in table.rows[0].cells]
            id_i = self._col(headers, "id")
            txt_i = self._col(headers, "requirement", "description", "text")
            if id_i is None or txt_i is None:  # missing columns are skipped, not fatal
                continue
            pri_i = self._col(headers, "priority")
            ver_i = self._col(headers, "verification")
            for row in table.rows[1:]:
                cells = [c.text.strip() for c in row.cells]
                rid = cells[id_i]
                if not self.id_pattern.match(rid) or rid in seen:
                    continue
                seen.add(rid)
                out.append(Requirement(
                    id=rid,
                    text=cells[txt_i],
                    priority=cells[pri_i] if pri_i is not None else "",
                    verification=cells[ver_i] if ver_i is not None else "",
                ))
        return out
