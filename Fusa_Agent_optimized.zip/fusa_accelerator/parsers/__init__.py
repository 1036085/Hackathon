"""Parser Service: ARXML, ECU extract, SWC design doc, functional requirements."""
from .arxml_parser import ArxmlParser
from .ecu_extract_parser import EcuExtractParser
from .requirement_parser import RequirementParser
from .swc_design_parser import SWCDesignParser
from .xml_utils import XmlValidationError

__all__ = [
    "ArxmlParser",
    "EcuExtractParser",
    "RequirementParser",
    "SWCDesignParser",
    "XmlValidationError",
    "merge_components",
]


def merge_components(*groups):
    """Merge component lists by name; ARXML wins for structure, design doc fills gaps."""
    merged = {}
    for group in groups:
        for c in group:
            cur = merged.get(c.name)
            if cur is None:
                merged[c.name] = c
                continue
            have_ports = {p.name for p in cur.ports}
            cur.ports += [p for p in c.ports if p.name not in have_ports]
            have_run = {r.name for r in cur.runnables}
            cur.runnables += [r for r in c.runnables if r.name not in have_run]
            cur.description = cur.description or c.description
            cur.ecu = cur.ecu or c.ecu
            cur.sources = sorted(set(cur.sources) | set(c.sources))
    return list(merged.values())
