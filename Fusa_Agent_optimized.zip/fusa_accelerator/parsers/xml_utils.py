"""Namespace-agnostic helpers + XML validation.

AUTOSAR files ship with a default namespace (http://autosar.org/schema/r4.0), and the
original `//SW-COMPONENT-TYPE` XPath silently matched nothing on them. Everything here
matches on local names instead, so it works with and without a namespace and across
schema versions (APPLICATION-/SERVICE-/COMPOSITION-/ECU-ABSTRACTION-SW-COMPONENT-TYPE ...).
"""
from __future__ import annotations

from typing import IO, Iterator, Union

from lxml import etree

Source = Union[str, bytes, IO[bytes]]

_PARSER = etree.XMLParser(
    resolve_entities=False,  # XXE hardening: files come from user uploads
    no_network=True,
    load_dtd=False,
    huge_tree=True,  # real ECU extracts are 100+ MB
    remove_comments=True,
    recover=False,
)


class XmlValidationError(ValueError):
    pass


def parse_xml(source: Source) -> etree._Element:
    """Parse a path / bytes / file object. Raises XmlValidationError with a readable message."""
    try:
        if isinstance(source, bytes):
            return etree.fromstring(source, _PARSER)
        return etree.parse(source, _PARSER).getroot()
    except (etree.XMLSyntaxError, OSError) as exc:
        raise XmlValidationError(f"Invalid XML: {exc}") from exc


def local(el: etree._Element) -> str:
    tag = el.tag
    return tag.rsplit("}", 1)[-1] if isinstance(tag, str) else ""


def iter_local(root: etree._Element, *names: str) -> Iterator[etree._Element]:
    """Single tree walk yielding every element whose local name is in `names`."""
    wanted = set(names)
    for el in root.iter():
        if local(el) in wanted:
            yield el


def child(el: etree._Element, name: str) -> etree._Element | None:
    for c in el:
        if local(c) == name:
            return c
    return None


def children(el: etree._Element, name: str) -> list[etree._Element]:
    return [c for c in el if local(c) == name]


def text_of(el: etree._Element | None, name: str) -> str | None:
    """Text of direct child `name` (stripped) or None."""
    if el is None:
        return None
    c = child(el, name)
    return c.text.strip() if c is not None and c.text and c.text.strip() else None


def short_name(el: etree._Element) -> str | None:
    return text_of(el, "SHORT-NAME")


def ref_tail(ref: str | None) -> str | None:
    """'/Pkg/Sub/Name' -> 'Name'."""
    return ref.rstrip("/").rsplit("/", 1)[-1] if ref else None


def require_autosar(root: etree._Element) -> None:
    if local(root) != "AUTOSAR":
        raise XmlValidationError(
            f"Root element is <{local(root)}>, expected <AUTOSAR>. Is this really an ARXML file?"
        )
