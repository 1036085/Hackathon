"""ARXML parser: SWC types, ports (with resolved interfaces), runnables, timing/events."""
from __future__ import annotations

from lxml import etree

from models import Component, Port, Runnable

from .xml_utils import (
    Source,
    child,
    children,
    iter_local,
    local,
    parse_xml,
    ref_tail,
    require_autosar,
    short_name,
    text_of,
)

SWC_TYPES = (
    "APPLICATION-SW-COMPONENT-TYPE",
    "SERVICE-SW-COMPONENT-TYPE",
    "SENSOR-ACTUATOR-SW-COMPONENT-TYPE",
    "ECU-ABSTRACTION-SW-COMPONENT-TYPE",
    "COMPLEX-DEVICE-DRIVER-SW-COMPONENT-TYPE",
    "COMPOSITION-SW-COMPONENT-TYPE",
    "SW-COMPONENT-TYPE",  # classic / simplified files
)
PORT_TAGS = {
    "P-PORT-PROTOTYPE": "P",
    "R-PORT-PROTOTYPE": "R",
    "PR-PORT-PROTOTYPE": "PR",
}
INTERFACE_REF_TAGS = (
    "PROVIDED-INTERFACE-TREF",
    "REQUIRED-INTERFACE-TREF",
    "PROVIDED-REQUIRED-INTERFACE-TREF",
    "INTERFACE-TREF",
)
EVENT_TAGS = ("TIMING-EVENT", "DATA-RECEIVED-EVENT", "OPERATION-INVOKED-EVENT",
              "INIT-EVENT", "BACKGROUND-EVENT", "SWC-MODE-SWITCH-EVENT",
              "DATA-RECEIVE-ERROR-EVENT", "ASYNCHRONOUS-SERVER-CALL-RETURNS-EVENT")


class ArxmlParser:
    """Single-pass parser; O(n) in document size (the original ran one XPath per field per SWC)."""

    def parse(self, source: Source) -> list[Component]:
        root = parse_xml(source)
        require_autosar(root)

        # One walk: index runnable events by the runnable they start.
        events_by_runnable: dict[str, list[tuple[str, float | None]]] = {}
        for ev in iter_local(root, *EVENT_TAGS):
            runnable = ref_tail(text_of(ev, "START-ON-EVENT-REF"))
            if not runnable:
                continue
            period_s = text_of(ev, "PERIOD")
            period_ms = float(period_s) * 1000.0 if period_s else None
            events_by_runnable.setdefault(runnable, []).append((local(ev), period_ms))

        components: list[Component] = []
        for swc in iter_local(root, *SWC_TYPES):
            name = short_name(swc)
            if not name:
                continue
            components.append(
                Component(
                    name=name,
                    kind=local(swc),
                    ports=self._ports(swc),
                    runnables=self._runnables(swc, events_by_runnable),
                    description=text_of(child(swc, "DESC") or swc, "L-2") or "",
                    sources=["arxml"],
                )
            )
        return components

    @staticmethod
    def _ports(swc: etree._Element) -> list[Port]:
        ports_el = child(swc, "PORTS")
        if ports_el is None:
            return []
        out = []
        for p in ports_el:
            direction = PORT_TAGS.get(local(p))
            if direction is None:
                continue
            iface = None
            for tag in INTERFACE_REF_TAGS:
                iface = ref_tail(text_of(p, tag))
                if iface:
                    break
            out.append(Port(name=short_name(p) or "?", direction=direction, interface=iface))
        return out

    @staticmethod
    def _runnables(swc: etree._Element, events: dict) -> list[Runnable]:
        out = []
        for r in iter_local(swc, "RUNNABLE-ENTITY"):
            rn = short_name(r)
            if not rn:
                continue
            evs = events.get(rn, [])
            periods = [p for _, p in evs if p is not None]
            out.append(Runnable(name=rn, period_ms=min(periods) if periods else None,
                                events=sorted({e for e, _ in evs})))
        return out
