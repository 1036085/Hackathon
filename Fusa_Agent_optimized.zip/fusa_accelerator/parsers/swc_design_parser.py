"""SWC design document (.docx) -> components with descriptions / ports / runnables.

The original only regex-matched `SWC_*` names and returned empty port/runnable lists (and used
`set()`, which made output order non-deterministic). This version also reads headings, tables
and the paragraphs under each SWC heading, preserving document order.
"""
from __future__ import annotations

import re
from typing import IO, Union

from docx import Document

from models import Component, Port, Runnable

SWC_RE = re.compile(r"\bSWC_[A-Za-z0-9_]+")
_PORT_RE = re.compile(r"^\s*(?:port)s?\s*[:\-]\s*(.+)$", re.I)
_RUN_RE = re.compile(r"^\s*runnables?\s*[:\-]\s*(.+)$", re.I)


class SWCDesignParser:
    def parse(self, source: Union[str, IO[bytes]]) -> list[Component]:
        doc = Document(source)
        comps: dict[str, Component] = {}
        current: Component | None = None

        for p in doc.paragraphs:
            text = p.text.strip()
            if not text:
                continue
            m = SWC_RE.search(text)
            is_heading = (p.style.name or "").lower().startswith("heading")
            if m and (is_heading or current is None or m.group(0) not in comps):
                name = m.group(0)
                current = comps.setdefault(name, Component(name=name, sources=["swc-design"]))
                if not is_heading and text != name:
                    current.description = current.description or text
                continue
            if current is None:
                continue
            if (pm := _PORT_RE.match(text)):
                for n in re.split(r"[,;]", pm.group(1)):
                    if n.strip():
                        current.ports.append(Port(name=n.strip(), direction="P"))
            elif (rm := _RUN_RE.match(text)):
                for n in re.split(r"[,;]", rm.group(1)):
                    if n.strip():
                        current.runnables.append(Runnable(name=n.strip()))
            elif not current.description:
                current.description = text

        # SWC mentioned only inside tables (name | description)
        for t in doc.tables:
            for row in t.rows:
                cells = [c.text.strip() for c in row.cells]
                for i, cell in enumerate(cells):
                    m = SWC_RE.fullmatch(cell)
                    if m:
                        c = comps.setdefault(cell, Component(name=cell, sources=["swc-design"]))
                        if not c.description and i + 1 < len(cells):
                            c.description = cells[i + 1]
        return list(comps.values())
