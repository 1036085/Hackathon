"""ECU extract parser: ECU instances and which SWC prototypes are mapped onto them."""
from __future__ import annotations

from models import Component

from .xml_utils import Source, child, children, iter_local, parse_xml, ref_tail, require_autosar, short_name, text_of


class EcuExtractParser:
    def parse(self, source: Source) -> dict[str, str]:
        """Return {swc_type_or_prototype_name: ecu_name}."""
        root = parse_xml(source)
        require_autosar(root)

        # ECU instance names, so mapping results can be reported with the real ECU name.
        ecus = {short_name(e) for e in iter_local(root, "ECU-INSTANCE") if short_name(e)}

        mapping: dict[str, str] = {}
        # SYSTEM-MAPPING -> SW-MAPPINGS -> SWC-TO-ECU-MAPPING (components + ecu-instance ref)
        for m in iter_local(root, "SWC-TO-ECU-MAPPING"):
            ecu = ref_tail(text_of(m, "ECU-INSTANCE-REF")) or (next(iter(ecus)) if len(ecus) == 1 else None)
            comps = child(m, "COMPONENT-IREFS")
            if comps is None or ecu is None:
                continue
            for iref in children(comps, "COMPONENT-IREF"):
                target = ref_tail(text_of(iref, "TARGET-COMPONENT-REF"))
                if target:
                    mapping[target] = ecu
        return mapping

    @staticmethod
    def apply(components: list[Component], mapping: dict[str, str]) -> None:
        """Annotate components in place. Mapping keys are prototype names, so match loosely."""
        for c in components:
            for proto, ecu in mapping.items():
                if proto == c.name or proto.lower() == c.name.lower() or c.name.lower() in proto.lower():
                    c.ecu = ecu
                    if "ecu-extract" not in c.sources:
                        c.sources.append("ecu-extract")
                    break
