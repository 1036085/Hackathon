"""Streamlit frontend: upload -> parse -> checks -> AI -> engineer review -> export.

Key difference from the original: Streamlit re-executes this script on every interaction, and the
old version re-ran every LLM call each time (including when the export button was pressed). Here
the pipeline runs only on the "Run analysis" click and its result lives in st.session_state.
"""
from __future__ import annotations

import io
from dataclasses import replace

import pandas as pd
import streamlit as st

from config import SETTINGS
from exporters import CsvExporter, ExcelExporter, WordExporter, build_tables
from llm import LLMClient
from parsers import (ArxmlParser, EcuExtractParser, RequirementParser, SWCDesignParser,
                     XmlValidationError, merge_components)
from pipeline import Pipeline

st.set_page_config(page_title="AI Powered Automotive FuSa Accelerator", layout="wide")
st.title("🚗 AI Powered Automotive FuSa Accelerator")

# ---------------------------------------------------------------- sidebar: model settings
with st.sidebar:
    st.header("Model")
    backend = st.selectbox("Backend", ["ollama", "vllm"], index=["ollama", "vllm"].index(SETTINGS.backend))
    model = st.text_input("Model", SETTINGS.model)
    url = st.text_input("Server URL", SETTINGS.ollama_url if backend == "ollama" else SETTINGS.vllm_url)
    workers = st.slider("Parallel requests", 1, 16, SETTINGS.max_workers)
    settings = replace(
        SETTINGS, backend=backend, model=model, max_workers=workers,
        **({"ollama_url": url} if backend == "ollama" else {"vllm_url": url}),
    )

# ---------------------------------------------------------------- inputs
c1, c2 = st.columns(2)
fr_file = c1.file_uploader("Functional Requirements (.docx)", type=["docx"])
swc_file = c1.file_uploader("SWC Design Document (.docx) — optional", type=["docx"])
arxml_file = c2.file_uploader("AUTOSAR ARXML", type=["arxml", "xml"])
ecu_file = c2.file_uploader("ECU Extract (.arxml) — optional", type=["arxml", "xml"])
template_file = c2.file_uploader("ISO 26262 Excel template — optional", type=["xlsx"])


@st.cache_data(show_spinner=False)
def parse_inputs(fr: bytes | None, swc: bytes | None, arxml: bytes, ecu: bytes | None):
    """Parsing is pure, so cache on file bytes. Uploads are parsed from memory, no temp files."""
    comps = ArxmlParser().parse(arxml)
    if ecu:
        EcuExtractParser.apply(comps, EcuExtractParser().parse(ecu))
    if swc:
        comps = merge_components(comps, SWCDesignParser().parse(io.BytesIO(swc)))
    reqs = RequirementParser().parse(io.BytesIO(fr)) if fr else []
    return comps, reqs


if arxml_file is None:
    st.info("Upload at least an ARXML file to begin.")
    st.stop()

try:
    components, requirements = parse_inputs(
        fr_file.getvalue() if fr_file else None,
        swc_file.getvalue() if swc_file else None,
        arxml_file.getvalue(),
        ecu_file.getvalue() if ecu_file else None,
    )
except XmlValidationError as e:
    st.error(f"Input validation failed: {e}")
    st.stop()
except Exception as e:  # corrupt .docx etc.
    st.error(f"Parsing error: {e}")
    st.stop()

st.success(f"Parsed {len(components)} components and {len(requirements)} requirements")
with st.expander("Parsed components"):
    st.dataframe(pd.DataFrame([
        {"SWC": c.name, "ECU": c.ecu, "Ports": len(c.ports),
         "Runnables": ", ".join(r.name for r in c.runnables), "Interfaces": ", ".join(c.interfaces)}
        for c in components]), use_container_width=True)

# ---------------------------------------------------------------- run
if st.button("Run analysis", type="primary"):
    bar = st.progress(0.0, text="Starting…")
    pipe = Pipeline(LLMClient(settings), settings)
    st.session_state["result"] = pipe.run(
        components, requirements, progress=lambda msg, f: bar.progress(f, text=msg))
    st.session_state.pop("approved", None)
    bar.empty()

result = st.session_state.get("result")
if result is None:
    st.stop()

# ---------------------------------------------------------------- results + review
st.header("Item Definition")
st.markdown(result.item_definition or "_not generated_")

if result.findings:
    st.warning("\n".join(f"- {f}" for f in result.findings))

tables = build_tables(result)
tab_names = ["HARA", "Safety Goals", "Requirements", "Test Cases", "Traceability", "Issues"]
tabs = st.tabs(tab_names)

# Engineer review & approval: every artefact starts unapproved; only approved rows are exported.
if "approved" not in st.session_state:
    st.session_state["approved"] = set()
approved: set[str] = st.session_state["approved"]

for tab, name in zip(tabs, tab_names):
    with tab:
        df = pd.DataFrame(tables[name])
        if df.empty:
            st.caption("No rows")
            continue
        if "id" in df.columns:
            df.insert(0, "approved", df["id"].isin(approved))
            edited = st.data_editor(
                df, key=f"ed_{name}", use_container_width=True, hide_index=True,
                disabled=[c for c in df.columns if c != "approved"],
            )
            approved -= set(df["id"])
            approved |= set(edited.loc[edited["approved"], "id"])
        else:
            st.dataframe(df, use_container_width=True, hide_index=True)

# ---------------------------------------------------------------- export
st.header("Export")
n_total = sum(len(tables[n]) for n in tab_names[:4])
st.caption(f"{len(approved)} of {n_total} artefacts approved")
only_approved = st.checkbox("Export approved items only", value=True)
sel = approved if only_approved else None

col_x, col_w, col_c = st.columns(3)

template = io.BytesIO(template_file.getvalue()) if template_file else None
try:
    xlsx_bytes = ExcelExporter().to_bytes(result, template, sel)
except Exception as e:  # bad template: fall back to a generated workbook
    st.warning(f"Template could not be used ({e}); generated a standard workbook instead.")
    xlsx_bytes = ExcelExporter().to_bytes(result, None, sel)

col_x.download_button("⬇ Excel", xlsx_bytes, "FuSa_Output.xlsx",
                      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
col_w.download_button("⬇ Word", WordExporter().to_bytes(result, sel), "FuSa_Output.docx",
                      "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
col_c.download_button("⬇ CSV (zip)", CsvExporter().to_zip(result, sel), "FuSa_Output_csv.zip",
                      "application/zip")
