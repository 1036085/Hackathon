"""Typed data model shared by every layer (replaces ad-hoc dicts and raw LLM strings)."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class Port:
    name: str
    direction: str  # "P" (provided) | "R" (required)
    interface: str | None = None


@dataclass
class Runnable:
    name: str
    period_ms: float | None = None
    events: list[str] = field(default_factory=list)


@dataclass
class Component:
    """One AUTOSAR software component, merged from ARXML / ECU extract / SWC design doc."""
    name: str
    kind: str = "SWC"
    ports: list[Port] = field(default_factory=list)
    runnables: list[Runnable] = field(default_factory=list)
    ecu: str | None = None
    description: str = ""
    sources: list[str] = field(default_factory=list)

    @property
    def interfaces(self) -> list[str]:
        return sorted({p.interface for p in self.ports if p.interface})

    def brief(self) -> dict[str, Any]:
        """Compact form for prompts (keeps token count down)."""
        return {
            "swc": self.name,
            "ecu": self.ecu,
            "ports": [f"{p.direction}:{p.name}:{p.interface or '?'}" for p in self.ports],
            "runnables": [
                {"name": r.name, "period_ms": r.period_ms, "events": r.events}
                for r in self.runnables
            ],
            "description": self.description,
        }


@dataclass
class Requirement:
    id: str
    text: str
    priority: str = ""
    verification: str = ""


@dataclass
class Hazard:
    id: str
    swc: str
    function: str
    malfunction: str
    hazard: str
    situation: str
    severity: str  # S0..S3
    exposure: str  # E0..E4
    controllability: str  # C0..C3
    asil: str  # computed deterministically, never taken from the LLM
    rationale: str = ""
    confidence: float = 1.0


@dataclass
class SafetyGoal:
    id: str
    hazard_id: str
    text: str
    asil: str
    safe_state: str
    ftti_ms: float | None = None


@dataclass
class SafetyRequirement:
    id: str
    level: str  # "FSR" | "TSR" | "SSR"
    parent_id: str  # safety goal id (FSR) or parent requirement id
    swc: str
    text: str
    asil: str
    mechanism: str = ""
    fault_reaction: str = ""
    verification_method: str = ""
    rationale: str = ""
    confidence: float = 1.0


@dataclass
class TestCase:
    id: str
    requirement_id: str
    kind: str  # functional | negative | boundary | fault-injection
    objective: str
    preconditions: str
    steps: list[str]
    expected: str


@dataclass
class SwcResult:
    """All artefacts for one component, plus review state."""
    swc: str
    hazards: list[Hazard] = field(default_factory=list)
    goals: list[SafetyGoal] = field(default_factory=list)
    requirements: list[SafetyRequirement] = field(default_factory=list)
    tests: list[TestCase] = field(default_factory=list)
    issues: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


@dataclass
class PipelineResult:
    components: list[Component]
    requirements: list[Requirement]
    item_definition: str
    results: list[SwcResult]
    findings: list[str]  # deterministic-engine findings that are not SWC-specific

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
