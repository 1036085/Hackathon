import io
import sys
from pathlib import Path

import openpyxl
import pytest
from docx import Document

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from config import Settings  # noqa: E402
from exporters import CsvExporter, ExcelExporter, WordExporter, build_tables  # noqa: E402
from llm.client import LLMClient, LLMError, extract_json  # noqa: E402
from parsers import (ArxmlParser, EcuExtractParser, RequirementParser,  # noqa: E402
                     XmlValidationError, merge_components)
from pipeline import Pipeline  # noqa: E402
from rules import DeterministicEngine, determine_asil, normalize_asil  # noqa: E402

ARXML = b"""<?xml version="1.0"?>
<AUTOSAR xmlns="http://autosar.org/schema/r4.0"><AR-PACKAGES><AR-PACKAGE>
<ELEMENTS>
 <SENDER-RECEIVER-INTERFACE><SHORT-NAME>If_Speaker</SHORT-NAME></SENDER-RECEIVER-INTERFACE>
 <APPLICATION-SW-COMPONENT-TYPE><SHORT-NAME>SWC_AudioManager</SHORT-NAME>
  <PORTS>
   <P-PORT-PROTOTYPE><SHORT-NAME>SpeakerOutput</SHORT-NAME>
     <PROVIDED-INTERFACE-TREF DEST="SENDER-RECEIVER-INTERFACE">/If/If_Speaker</PROVIDED-INTERFACE-TREF></P-PORT-PROTOTYPE>
   <R-PORT-PROTOTYPE><SHORT-NAME>AudioIn</SHORT-NAME></R-PORT-PROTOTYPE>
  </PORTS>
  <INTERNAL-BEHAVIORS><SWC-INTERNAL-BEHAVIOR>
   <RUNNABLES><RUNNABLE-ENTITY><SHORT-NAME>ProcessAudio</SHORT-NAME></RUNNABLE-ENTITY></RUNNABLES>
   <EVENTS><TIMING-EVENT><SHORT-NAME>T10</SHORT-NAME>
     <START-ON-EVENT-REF DEST="RUNNABLE-ENTITY">/X/SWC_AudioManager/ProcessAudio</START-ON-EVENT-REF>
     <PERIOD>0.01</PERIOD></TIMING-EVENT></EVENTS>
  </SWC-INTERNAL-BEHAVIOR></INTERNAL-BEHAVIORS>
 </APPLICATION-SW-COMPONENT-TYPE>
 <APPLICATION-SW-COMPONENT-TYPE><SHORT-NAME>SWC_Empty</SHORT-NAME></APPLICATION-SW-COMPONENT-TYPE>
</ELEMENTS></AR-PACKAGE></AR-PACKAGES></AUTOSAR>"""

ECU = b"""<AUTOSAR xmlns="http://autosar.org/schema/r4.0"><ELEMENTS>
<ECU-INSTANCE><SHORT-NAME>Ecu_Main</SHORT-NAME></ECU-INSTANCE>
<SWC-TO-ECU-MAPPING><SHORT-NAME>m</SHORT-NAME><COMPONENT-IREFS><COMPONENT-IREF>
 <TARGET-COMPONENT-REF DEST="SW-COMPONENT-PROTOTYPE">/Sys/SWC_AudioManager</TARGET-COMPONENT-REF>
</COMPONENT-IREF></COMPONENT-IREFS><ECU-INSTANCE-REF DEST="ECU-INSTANCE">/E/Ecu_Main</ECU-INSTANCE-REF>
</SWC-TO-ECU-MAPPING></ELEMENTS></AUTOSAR>"""


class FakeLLM:
    """Routes on prompt text; counts calls."""

    def __init__(self):
        self.calls = 0

    def complete_json(self, system, user):
        self.calls += 1
        if "Item Definition" in user:
            return {"item_name": "Audio", "purpose": "p", "operational_modes": ["on"],
                    "interfaces": ["i"], "boundary": "b", "dependencies": []}
        if "HARA" in user:
            return {"hazards": [
                {"function": "audio", "malfunction": "stuck", "hazard": "h", "situation": "s",
                 "severity": "S3", "exposure": "E3", "controllability": "C2", "rationale": "r",
                 "confidence": 0.9, "safety_goal": "Avoid stuck output", "safe_state": "mute",
                 "ftti_ms": 100},
                {"function": "audio", "malfunction": "quiet", "hazard": "h2", "situation": "s",
                 "severity": "S1", "exposure": "E1", "controllability": "C1", "confidence": 0.4}]}
        if "derive requirements" in user:
            return {"requirements": [
                {"goal_id": "SG-01-01", "level": "SSR", "text": "ssr", "verification_method": "test"},
                {"goal_id": "SG-01-01", "level": "FSR", "text": "fsr", "verification_method": "review"},
                {"goal_id": "SG-01-01", "level": "TSR", "text": "tsr", "verification_method": "analysis"},
                {"goal_id": "BOGUS", "level": "SSR", "text": "dropped"}]}
        if "test cases" in user:
            return {"tests": [
                {"requirement_id": "SSR-01-01", "kind": "negative", "objective": "o",
                 "preconditions": "p", "steps": ["a", "b"], "expected": "e"},
                {"requirement_id": "NOPE", "objective": "hallucinated"}]}
        raise AssertionError(user[:80])


# ------------------------------------------------------------------ parsers
def test_arxml_namespaced():
    comps = {c.name: c for c in ArxmlParser().parse(ARXML)}
    a = comps["SWC_AudioManager"]
    assert [p.name for p in a.ports] == ["SpeakerOutput", "AudioIn"]
    assert a.ports[0].interface == "If_Speaker" and a.ports[1].interface is None
    assert a.runnables[0].name == "ProcessAudio"
    assert a.runnables[0].period_ms == pytest.approx(10.0)
    assert a.runnables[0].events == ["TIMING-EVENT"]


def test_ecu_mapping_and_merge():
    comps = ArxmlParser().parse(ARXML)
    EcuExtractParser.apply(comps, EcuExtractParser().parse(ECU))
    assert {c.name: c.ecu for c in comps}["SWC_AudioManager"] == "Ecu_Main"
    merged = merge_components(comps, comps)
    assert len(merged) == 2


def test_invalid_xml_and_xxe():
    with pytest.raises(XmlValidationError):
        ArxmlParser().parse(b"<AUTOSAR><oops>")
    with pytest.raises(XmlValidationError, match="expected <AUTOSAR>"):
        ArxmlParser().parse(b"<html/>")
    evil = b'<?xml version="1.0"?><!DOCTYPE a [<!ENTITY x SYSTEM "file:///etc/passwd">]><AUTOSAR>&x;</AUTOSAR>'
    assert ArxmlParser().parse(evil) == []  # entity not expanded, nothing leaked


def test_requirement_parser_any_prefix():
    d = Document()
    t = d.add_table(rows=3, cols=3)
    for c, h in zip(t.rows[0].cells, ["ID", "Requirement", "Priority"]):
        c.text = h
    for row, (i, txt) in zip(t.rows[1:], [("BRK-FR-1", "Brake"), ("BRK-FR-1", "dup")]):
        row.cells[0].text, row.cells[1].text = i, txt
    buf = io.BytesIO()
    d.save(buf)
    reqs = RequirementParser().parse(io.BytesIO(buf.getvalue()))
    assert [r.id for r in reqs] == ["BRK-FR-1"]  # non-ACC prefix kept, duplicate id dropped


# ------------------------------------------------------------------ rules
def test_asil_table_full():
    assert determine_asil("S3", "E4", "C3") == "ASIL-D"
    assert determine_asil("S3", "E4", "C2") == "ASIL-C"
    assert determine_asil("S3", "E3", "C2") == "ASIL-B"  # missing from the original 6-row dict
    assert determine_asil("S2", "E3", "C3") == "ASIL-B"
    assert determine_asil("S1", "E4", "C3") == "ASIL-B"
    assert determine_asil("S1", "E3", "C3") == "ASIL-A"
    assert determine_asil("S3", "E4", "C1") == "ASIL-B"
    assert determine_asil("S3", "E3", "C1") == "ASIL-A"
    assert determine_asil("S2", "E2", "C3") == "ASIL-A"
    assert determine_asil("S2", "E2", "C2") == "QM"
    assert determine_asil("S1", "E1", "C1") == "QM"
    assert determine_asil("S0", "E4", "C3") == "QM"
    assert determine_asil("S4", "E4", "C3") == "QM"  # invalid rating
    assert normalize_asil("asil b") == "ASIL-B" and normalize_asil("x") == "QM"


def test_structural_checks():
    comps = ArxmlParser().parse(ARXML)
    eng = DeterministicEngine()
    issues = eng.validate_component(comps[1])
    assert any("no ports" in i for i in issues) and any("no runnables" in i for i in issues)
    issues = eng.validate_component(comps[0])
    assert any("'AudioIn' has no interface" in i for i in issues)


# ------------------------------------------------------------------ end to end
@pytest.fixture(scope="module")
def result():
    comps = ArxmlParser().parse(ARXML)
    llm = FakeLLM()
    s = Settings(max_workers=2)
    res = Pipeline(llm, s).run(comps, [])
    res._llm_calls = llm.calls
    return res


def test_pipeline_artifacts(result):
    r = result.results[0]
    assert [h.asil for h in r.hazards] == ["ASIL-B", "QM"]  # computed, not model-supplied
    assert [g.id for g in r.goals] == ["SG-01-01"]  # QM hazard produced no goal
    ids = {q.id: q for q in r.requirements}
    assert set(ids) == {"FSR-01-01", "TSR-01-01", "SSR-01-01"}  # bogus goal dropped
    assert ids["FSR-01-01"].parent_id == "SG-01-01"
    assert ids["TSR-01-01"].parent_id == "FSR-01-01"
    assert ids["SSR-01-01"].parent_id == "TSR-01-01"
    assert all(q.asil == "ASIL-B" for q in ids.values())
    assert [t.requirement_id for t in r.tests] == ["SSR-01-01"]  # hallucinated link dropped
    # item def (1) + 2 SWCs; second SWC has no ports/hazards but still gets a HARA call
    assert result.item_definition.startswith("**Item:**")
    assert any("low model confidence" in i for i in r.issues)


def test_failure_isolated():
    class Boom(FakeLLM):
        def complete_json(self, system, user):
            if "HARA" in user and "SWC_Empty" in user:
                raise LLMError("down")
            return super().complete_json(system, user)

    res = Pipeline(Boom(), Settings(max_workers=2)).run(ArxmlParser().parse(ARXML), [])
    assert res.results[0].hazards and res.results[1].errors and not res.results[1].hazards


def test_traceability_chain(result):
    rows = Pipeline.traceability(result)
    full = [r for r in rows if r["SSR"]]
    assert full[0]["Hazard"] == "HZ-01-01" and full[0]["Safety Goal"] == "SG-01-01"
    assert (full[0]["FSR"], full[0]["TSR"], full[0]["SSR"], full[0]["Test Case"]) == (
        "FSR-01-01", "TSR-01-01", "SSR-01-01", "TC-01-01")
    assert full[0]["Gap"] == ""


def test_exports(result, tmp_path):
    x = ExcelExporter().export(result, tmp_path / "o.xlsx")
    wb = openpyxl.load_workbook(x)
    assert wb.sheetnames == ["HARA", "Safety Goals", "Requirements", "Test Cases",
                             "Traceability", "Issues"]
    assert wb["HARA"].max_row == 5  # header + 2 hazards for each of 2 SWCs
    WordExporter().export(result, tmp_path / "o.docx")
    assert Document(tmp_path / "o.docx").tables
    files = CsvExporter().export(result, tmp_path / "csv")
    assert len(files) == 6
    assert CsvExporter().to_zip(result)[:2] == b"PK"


def test_approval_filter(result):
    t = build_tables(result, {"HZ-01-01", "SG-01-01"})
    assert [h["id"] for h in t["HARA"]] == ["HZ-01-01"]
    assert t["Requirements"] == [] and t["Test Cases"] == []
    # chain is incomplete => no traceability rows reference unapproved items
    assert all(not r["SSR"] for r in t["Traceability"])


def test_excel_template_fill_and_injection(result, tmp_path):
    tpl = openpyxl.Workbook()
    ws = tpl.active
    ws.title = "2_HARA"
    ws.append(["Concept-phase template"])
    ws.append(["Hazard ID", "Function", "Malfunction", "Severity", "Exposure", "Controllability", "ASIL"])
    for _ in range(8):
        ws.append(["stale", "stale", "stale"])
    tpl.save(tmp_path / "t.xlsx")
    out = ExcelExporter().export(result, tmp_path / "o.xlsx", template_file=tmp_path / "t.xlsx")
    ws = openpyxl.load_workbook(out)["2_HARA"]
    assert [c.value for c in ws[3]][:3] == ["HZ-01-01", "audio", "stuck"]
    assert ws["G3"].value == "ASIL-B" and ws["A6"].value == "HZ-02-02" and ws["A7"].value is None  # stale rows cleared
    assert ExcelExporter._cell("=cmd|' /C calc'!A0").startswith("'")


# ------------------------------------------------------------------ llm client
def test_extract_json():
    assert extract_json('<think>x {1}</think>```json\n{"a": 1}\n```') == {"a": 1}
    assert extract_json('Sure! Here: {"a": {"b": "}"}} done') == {"a": {"b": "}"}}
    with pytest.raises(LLMError):
        extract_json("no json")


def test_client_retry_and_cache(tmp_path, monkeypatch):
    s = Settings(cache_dir=str(tmp_path), max_retries=3)
    c = LLMClient(s)
    seq = iter(["garbage", '{"ok": true}'])
    calls = []
    monkeypatch.setattr(c, "_chat", lambda sys_, usr: calls.append(1) or next(seq))
    monkeypatch.setattr("time.sleep", lambda *_: None)
    assert c.complete_json("s", "u") == {"ok": True} and len(calls) == 2
    assert c.complete_json("s", "u") == {"ok": True} and len(calls) == 2  # served from cache
