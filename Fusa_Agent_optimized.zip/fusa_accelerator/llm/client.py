"""LLM client for Ollama and vLLM (OpenAI-compatible) with retries, caching and JSON repair."""
from __future__ import annotations

import hashlib
import json
import re
import time
from pathlib import Path
from typing import Any, Protocol

import requests

from config import SETTINGS, Settings


class LLM(Protocol):
    def complete_json(self, system: str, user: str) -> Any: ...


class LLMError(RuntimeError):
    pass


_THINK_RE = re.compile(r"<think>.*?</think>", re.S)
_FENCE_RE = re.compile(r"^```(?:json)?\s*|\s*```$", re.M)


def extract_json(raw: str) -> Any:
    """Robustly pull one JSON value out of model output (think blocks, fences, prose)."""
    text = _FENCE_RE.sub("", _THINK_RE.sub("", raw)).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    # fall back to the first balanced {...} or [...] block
    for open_c, close_c in (("{", "}"), ("[", "]")):
        start = text.find(open_c)
        while start != -1:
            depth, in_str, esc = 0, False, False
            for i in range(start, len(text)):
                ch = text[i]
                if in_str:
                    esc = (not esc and ch == "\\")
                    if ch == '"' and not esc:
                        in_str = False
                    continue
                if ch == '"':
                    in_str = True
                elif ch == open_c:
                    depth += 1
                elif ch == close_c:
                    depth -= 1
                    if depth == 0:
                        try:
                            return json.loads(text[start:i + 1])
                        except json.JSONDecodeError:
                            break
            start = text.find(open_c, start + 1)
    raise LLMError(f"Model did not return valid JSON: {raw[:200]!r}")


class LLMClient:
    def __init__(self, settings: Settings = SETTINGS):
        self.s = settings
        self.session = requests.Session()  # connection reuse across calls
        self.cache_dir = Path(settings.cache_dir)

    # -- public -------------------------------------------------------------------------
    def complete_json(self, system: str, user: str) -> Any:
        key = self._key(system, user)
        cached = self._cache_get(key)
        if cached is not None:
            return cached

        last: Exception | None = None
        for attempt in range(self.s.max_retries):
            try:
                value = extract_json(self._chat(system, user))
                self._cache_put(key, value)
                return value
            except (requests.RequestException, LLMError, KeyError) as exc:
                last = exc
                time.sleep(min(2 ** attempt, 8))
        raise LLMError(f"LLM call failed after {self.s.max_retries} attempts: {last}")

    # -- backends -----------------------------------------------------------------------
    def _chat(self, system: str, user: str) -> str:
        messages = [{"role": "system", "content": system}, {"role": "user", "content": user}]
        if self.s.backend == "vllm":
            r = self.session.post(
                f"{self.s.vllm_url.rstrip('/')}/chat/completions",
                json={
                    "model": self.s.model,
                    "messages": messages,
                    "temperature": self.s.temperature,
                    "max_tokens": self.s.max_tokens,
                    "response_format": {"type": "json_object"},
                    "chat_template_kwargs": {"enable_thinking": self.s.think},
                },
                timeout=self.s.timeout_s,
            )
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"]
        r = self.session.post(
            f"{self.s.ollama_url.rstrip('/')}/api/chat",
            json={
                "model": self.s.model,
                "messages": messages,
                "stream": False,
                "format": "json",
                "think": self.s.think,
                "options": {"temperature": self.s.temperature, "num_predict": self.s.max_tokens},
            },
            timeout=self.s.timeout_s,
        )
        r.raise_for_status()
        return r.json()["message"]["content"]

    # -- disk cache (identical prompt => identical answer; makes reruns instant) ---------
    def _key(self, system: str, user: str) -> str:
        blob = json.dumps([self.s.backend, self.s.model, self.s.temperature, system, user])
        return hashlib.sha256(blob.encode()).hexdigest()

    def _cache_get(self, key: str) -> Any | None:
        f = self.cache_dir / f"{key}.json"
        try:
            return json.loads(f.read_text(encoding="utf-8")) if f.exists() else None
        except (OSError, json.JSONDecodeError):
            return None

    def _cache_put(self, key: str, value: Any) -> None:
        try:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
            (self.cache_dir / f"{key}.json").write_text(json.dumps(value), encoding="utf-8")
        except OSError:
            pass
