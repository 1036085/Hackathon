"""Flatten typed artefacts into export-ready row dicts (single source for Excel/Word/CSV)."""
from __future__ import annotations

from dataclasses import asdict

from agents import TraceabilityAgent
from models import PipelineResult

SHEETS: dict[str, list[str]] = {
    "HARA": ["id", "swc", "function", "malfunction", "hazard", "situation", "severity",
             "exposure", "controllability", "asil", "rationale", "confidence"],
    "Safety Goals": ["id", "hazard_id", "text", "asil", "safe_state", "ftti_ms"],
    "Requirements": ["id", "level", "parent_id", "swc", "text", "asil", "mechanism",
                     "fault_reaction", "verification_method", "rationale", "confidence"],
    "Test Cases": ["id", "requirement_id", "kind", "objective", "preconditions", "steps",
                   "expected"],
    "Traceability": TraceabilityAgent.COLUMNS,
    "Issues": ["swc", "issue"],
}


def build_tables(
    result: PipelineResult,
    approved: set[str] | None = None,
) -> dict[str, list[dict]]:
    """`approved` = set of artefact IDs the engineer signed off. None => export everything."""
    keep = (lambda i: True) if approved is None else (lambda i: i in approved)

    def rows(attr: str):
        for res in result.results:
            for obj in getattr(res, attr):
                if keep(obj.id):
                    d = asdict(obj)
                    if "steps" in d:
                        d["steps"] = "\n".join(f"{n}. {s}" for n, s in enumerate(d["steps"], 1))
                    yield d

    tables = {
        "HARA": list(rows("hazards")),
        "Safety Goals": list(rows("goals")),
        "Requirements": list(rows("requirements")),
        "Test Cases": list(rows("tests")),
    }
    kept_ids = {r["id"] for t in tables.values() for r in t}
    trace = TraceabilityAgent().build(result.results)
    if approved is not None:  # keep only rows whose whole chain is approved
        trace = [r for r in trace
                 if all(not r[k] or all(x.strip() in kept_ids for x in r[k].split(","))
                        for k in ("Hazard", "Safety Goal", "FSR", "TSR", "SSR", "Test Case"))]
    tables["Traceability"] = trace
    tables["Issues"] = [{"swc": r.swc, "issue": i} for r in result.results
                        for i in r.issues + [f"ERROR: {e}" for e in r.errors]] + \
                       [{"swc": "(project)", "issue": f} for f in result.findings]
    return tables
