from __future__ import annotations

import io
from pathlib import Path

from docx import Document
from docx.shared import Pt

from models import PipelineResult

from .tables import build_tables


class WordExporter:
    """TSR / SSR / safety-goal report as .docx."""

    def build(self, result: PipelineResult, approved: set[str] | None = None) -> Document:
        t = build_tables(result, approved)
        doc = Document()
        doc.styles["Normal"].font.size = Pt(10)
        doc.add_heading("ISO 26262 Concept & Software Safety Work Products", 0)

        if result.item_definition:
            doc.add_heading("1. Item Definition", 1)
            for line in result.item_definition.splitlines():
                if line.strip():
                    doc.add_paragraph(line.replace("**", ""))

        doc.add_heading("2. Safety Goals", 1)
        self._table(doc, ["ID", "Hazard", "ASIL", "Safety Goal", "Safe State", "FTTI (ms)"],
                    [[g["id"], g["hazard_id"], g["asil"], g["text"], g["safe_state"],
                      g["ftti_ms"] or ""] for g in t["Safety Goals"]])

        for n, (level, title) in enumerate((("FSR", "Functional Safety Requirements"),
                                            ("TSR", "Technical Safety Requirements"),
                                            ("SSR", "Software Safety Requirements")), 3):
            doc.add_heading(f"{n}. {title}", 1)
            self._table(doc, ["ID", "Parent", "SWC", "ASIL", "Requirement", "Mechanism",
                              "Fault Reaction", "Verification"],
                        [[r["id"], r["parent_id"], r["swc"], r["asil"], r["text"], r["mechanism"],
                          r["fault_reaction"], r["verification_method"]]
                         for r in t["Requirements"] if r["level"] == level])

        doc.add_heading("6. Verification Test Cases", 1)
        for tc in t["Test Cases"]:
            doc.add_heading(f"{tc['id']} ({tc['kind']}) -> {tc['requirement_id']}", 3)
            doc.add_paragraph(f"Objective: {tc['objective']}")
            doc.add_paragraph(f"Preconditions: {tc['preconditions']}")
            doc.add_paragraph(tc["steps"])
            doc.add_paragraph(f"Expected: {tc['expected']}")

        issues = t["Issues"]
        if issues:
            doc.add_heading("7. Open Findings", 1)
            for i in issues:
                doc.add_paragraph(f"[{i['swc']}] {i['issue']}", style="List Bullet")
        return doc

    def export(self, result: PipelineResult, output_file, approved: set[str] | None = None) -> Path:
        out = Path(output_file)
        out.parent.mkdir(parents=True, exist_ok=True)
        self.build(result, approved).save(out)
        return out

    def to_bytes(self, result: PipelineResult, approved: set[str] | None = None) -> bytes:
        buf = io.BytesIO()
        self.build(result, approved).save(buf)
        return buf.getvalue()

    @staticmethod
    def _table(doc, header: list[str], rows: list[list]) -> None:
        if not rows:
            doc.add_paragraph("(none)")
            return
        tbl = doc.add_table(rows=1, cols=len(header), style="Light Grid Accent 1")
        for c, h in zip(tbl.rows[0].cells, header):
            c.text = h
        for r in rows:
            for c, v in zip(tbl.add_row().cells, r):
                c.text = str(v)
