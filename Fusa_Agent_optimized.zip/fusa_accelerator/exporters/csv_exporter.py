from __future__ import annotations

import csv
import io
import zipfile
from pathlib import Path

from models import PipelineResult

from .tables import SHEETS, build_tables


def _safe(v):
    return "'" + v if isinstance(v, str) and v[:1] in ("=", "+", "-", "@") else v


class CsvExporter:
    """One CSV per artefact table. `to_zip` returns bytes for a single download button."""

    def export(self, result: PipelineResult, out_dir, approved: set[str] | None = None) -> list[Path]:
        out = Path(out_dir)
        out.mkdir(parents=True, exist_ok=True)
        paths = []
        for name, rows in build_tables(result, approved).items():
            p = out / f"{name.replace(' ', '_')}.csv"
            p.write_text(self._csv(name, rows), encoding="utf-8-sig")  # BOM: Excel opens UTF-8
            paths.append(p)
        return paths

    def to_zip(self, result: PipelineResult, approved: set[str] | None = None) -> bytes:
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            for name, rows in build_tables(result, approved).items():
                z.writestr(f"{name.replace(' ', '_')}.csv", "﻿" + self._csv(name, rows))
        return buf.getvalue()

    @staticmethod
    def _csv(name: str, rows: list[dict]) -> str:
        buf = io.StringIO()
        w = csv.DictWriter(buf, fieldnames=SHEETS[name], extrasaction="ignore")
        w.writeheader()
        w.writerows({k: _safe(v) for k, v in r.items()} for r in rows)
        return buf.getvalue()
