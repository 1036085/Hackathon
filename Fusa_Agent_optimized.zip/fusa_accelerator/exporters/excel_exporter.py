from __future__ import annotations

import io
import os
from pathlib import Path
from typing import IO, Union

import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from models import PipelineResult

from .tables import SHEETS, build_tables

HEADER_FILL = PatternFill("solid", fgColor="1F3864")
ASIL_FILL = {"ASIL-D": "F4B6B6", "ASIL-C": "F8CBAD", "ASIL-B": "FFE699", "ASIL-A": "E2EFDA"}


def _norm(h: str) -> str:
    return "".join(ch for ch in str(h or "").lower() if ch.isalnum())


class ExcelExporter:
    """Writes the artefacts to .xlsx.

    With a template: each sheet whose name contains a table name (e.g. '2_HARA') is filled by
    matching header text to field names -- no hard-coded column numbers (the original wrote
    columns 1-3 only, assumed dict items, and overwrote row 2 downward without clearing).
    Without a template: a clean workbook is generated.
    """

    def build(self, result: PipelineResult, template: Union[str, os.PathLike, IO[bytes], None] = None,
              approved: set[str] | None = None) -> openpyxl.Workbook:
        tables = build_tables(result, approved)
        if template is not None:
            wb = openpyxl.load_workbook(template)
            used = self._fill_template(wb, tables)
        else:
            wb = openpyxl.Workbook()
            wb.remove(wb.active)
            used = set()
        for name, rows in tables.items():
            if name not in used:
                self._write_new_sheet(wb, name, rows)
        return wb

    def export(self, result: PipelineResult, output_file: str | os.PathLike,
               template_file: Union[str, os.PathLike, IO[bytes], None] = None,
               approved: set[str] | None = None) -> Path:
        out = Path(output_file)
        out.parent.mkdir(parents=True, exist_ok=True)
        self.build(result, template_file, approved).save(out)
        return out

    def to_bytes(self, result: PipelineResult, template: Union[str, os.PathLike, IO[bytes], None] = None,
                 approved: set[str] | None = None) -> bytes:
        buf = io.BytesIO()
        self.build(result, template, approved).save(buf)
        return buf.getvalue()

    def _fill_template(self, wb, tables) -> set[str]:
        used: set[str] = set()
        for ws in wb.worksheets:
            for name, rows in tables.items():
                if _norm(name) not in _norm(ws.title) or name in used:
                    continue
                header_row = self._find_header_row(ws, SHEETS[name])
                if header_row is None:
                    continue
                cols = {}
                for c in range(1, ws.max_column + 1):
                    cols[_norm(ws.cell(header_row, c).value)] = c
                fields = {f: cols[_norm(f)] for f in SHEETS[name] if _norm(f) in cols}
                # alias common template headings
                for alias, f in (("requirementstatement", "text"), ("requirement", "text"),
                                 ("safetygoal", "text"), ("goal", "text"),
                                 ("hazardid", "id"), ("hazardevent", "hazard"),
                                 ("controllabilityc", "controllability")):
                    if alias in cols and f not in fields:
                        fields[f] = cols[alias]
                if not fields:
                    continue
                # clear stale data below the header, then write
                for r in range(header_row + 1, ws.max_row + 1):
                    for c in fields.values():
                        ws.cell(r, c).value = None
                for i, row in enumerate(rows, header_row + 1):
                    for f, c in fields.items():
                        ws.cell(i, c, self._cell(row.get(f)))
                used.add(name)
        return used

    @staticmethod
    def _find_header_row(ws, fields: list[str], scan: int = 15) -> int | None:
        want = {_norm(f) for f in fields}
        for r in range(1, min(ws.max_row, scan) + 1):
            hits = sum(1 for c in range(1, ws.max_column + 1) if _norm(ws.cell(r, c).value) in want)
            if hits >= 2:
                return r
        return None

    def _write_new_sheet(self, wb, name: str, rows: list[dict]) -> None:
        ws = wb.create_sheet(name[:31])
        cols = SHEETS[name]
        ws.append([c.replace("_", " ").title() if name != "Traceability" else c for c in cols])
        for c in ws[1]:
            c.font, c.fill = Font(bold=True, color="FFFFFF"), HEADER_FILL
        for row in rows:
            ws.append([self._cell(row.get(c)) for c in cols])
        for i, col in enumerate(cols, 1):
            width = max([len(str(col))] + [len(str(r.get(col, "")).split("\n")[0]) for r in rows[:200]])
            ws.column_dimensions[get_column_letter(i)].width = min(60, width + 2)
            for cell in ws[get_column_letter(i)][1:]:
                cell.alignment = Alignment(wrap_text=True, vertical="top")
                if cell.value in ASIL_FILL:
                    cell.fill = PatternFill("solid", fgColor=ASIL_FILL[cell.value])
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions

    @staticmethod
    def _cell(v):
        # guard against spreadsheet formula injection from LLM / document text
        if isinstance(v, str) and v[:1] in ("=", "+", "-", "@"):
            return "'" + v
        return v
