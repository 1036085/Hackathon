"""Orchestrates: parse -> deterministic checks -> AI agents -> deterministic checks -> artefacts."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from typing import Callable

from agents import (HaraAgent, ItemDefinitionAgent, SafetyRequirementAgent, TestCaseAgent,
                    TraceabilityAgent)
from config import SETTINGS, Settings
from llm import LLM, LLMClient
from models import Component, PipelineResult, Requirement, SwcResult
from rules import DeterministicEngine

Progress = Callable[[str, float], None]


class Pipeline:
    def __init__(self, llm: LLM | None = None, settings: Settings = SETTINGS):
        self.s = settings
        self.llm = llm or LLMClient(settings)
        self.engine = DeterministicEngine()
        self.hara = HaraAgent(self.llm)
        self.srs = SafetyRequirementAgent(self.llm)
        self.tests = TestCaseAgent(self.llm)
        self.item = ItemDefinitionAgent(self.llm)

    def run(
        self,
        components: list[Component],
        requirements: list[Requirement],
        progress: Progress | None = None,
    ) -> PipelineResult:
        note = progress or (lambda msg, frac: None)

        # 1. deterministic structural checks -- cheap, run before spending LLM time
        findings = self.engine.validate_all(components, requirements)

        # 2. item definition (1 call) runs concurrently with the per-SWC work
        with ThreadPoolExecutor(max_workers=max(1, self.s.max_workers)) as pool:
            item_f = pool.submit(self._safe_item, requirements, components)
            swc_f = [pool.submit(self._analyse, c, i, requirements)
                     for i, c in enumerate(components, 1)]
            results = []
            for n, f in enumerate(swc_f, 1):
                results.append(f.result())  # keeps input order
                note(f"Analysed {results[-1].swc}", n / max(1, len(swc_f)))
            item_def = item_f.result()

        return PipelineResult(components, requirements, item_def, results, findings)

    # ---------------------------------------------------------------------------------
    def _safe_item(self, reqs, comps) -> str:
        try:
            return self.item.generate(reqs, comps)
        except Exception as exc:  # item definition is optional context, never fatal
            return f"_Item definition unavailable: {exc}_"

    def _analyse(self, comp: Component, idx: int, reqs: list[Requirement]) -> SwcResult:
        res = SwcResult(swc=comp.name, issues=self.engine.validate_component(comp))
        # One failing stage must not discard the SWC's earlier results or other SWCs.
        try:
            res.hazards, res.goals = self.hara.generate(comp, idx, self._related(comp, reqs))
            res.requirements = self.srs.generate(comp, idx, res.goals)
            res.tests = self.tests.generate(comp, idx, res.requirements)
        except Exception as exc:
            res.errors.append(f"{type(exc).__name__}: {exc}")
        res.issues += self.engine.validate_result(res, self.s.confidence_threshold)
        return res

    @staticmethod
    def _related(comp: Component, reqs: list[Requirement], limit: int = 15) -> list[Requirement]:
        """Prompt-size control: only requirements that mention this SWC, its runnables or ports;
        fall back to the first few if none match."""
        terms = {comp.name.lower(), *(r.name.lower() for r in comp.runnables),
                 *(p.name.lower() for p in comp.ports)}
        hit = [r for r in reqs if any(t and t in r.text.lower() for t in terms)]
        return (hit or reqs)[:limit]

    @staticmethod
    def traceability(result: PipelineResult) -> list[dict]:
        return TraceabilityAgent().build(result.results)
