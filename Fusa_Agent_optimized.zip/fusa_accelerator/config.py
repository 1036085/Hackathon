"""Central configuration. Every value can be overridden with an environment variable."""
from __future__ import annotations

import os
from dataclasses import dataclass, field


def _env(name: str, default: str) -> str:
    return os.environ.get(f"FUSA_{name}", default)


@dataclass(frozen=True)
class Settings:
    # LLM backend: "ollama" (native /api/chat) or "vllm" (OpenAI-compatible /v1/chat/completions)
    backend: str = field(default_factory=lambda: _env("BACKEND", "ollama"))
    ollama_url: str = field(default_factory=lambda: _env("OLLAMA_URL", "http://localhost:11434"))
    vllm_url: str = field(default_factory=lambda: _env("VLLM_URL", "http://localhost:8000/v1"))
    model: str = field(default_factory=lambda: _env("MODEL", "qwen3:27b"))
    timeout_s: float = field(default_factory=lambda: float(_env("TIMEOUT_S", "180")))
    max_retries: int = field(default_factory=lambda: int(_env("MAX_RETRIES", "3")))
    temperature: float = field(default_factory=lambda: float(_env("TEMPERATURE", "0.1")))
    max_tokens: int = field(default_factory=lambda: int(_env("MAX_TOKENS", "4096")))
    # Qwen3 "thinking" mode costs a lot of latency; structured extraction does not need it.
    think: bool = field(default_factory=lambda: _env("THINK", "0") == "1")
    # Parallel LLM requests (one SWC per worker). vLLM batches these; Ollama queues them.
    max_workers: int = field(default_factory=lambda: int(_env("MAX_WORKERS", "4")))
    cache_dir: str = field(default_factory=lambda: _env("CACHE_DIR", ".cache/llm"))
    # Items whose self-reported confidence is below this are flagged for engineer review.
    confidence_threshold: float = field(
        default_factory=lambda: float(_env("CONFIDENCE_THRESHOLD", "0.70"))
    )


SETTINGS = Settings()
