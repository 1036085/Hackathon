"""Headless run (no Streamlit): python run_cli.py model.arxml [requirements.docx] [ecu.arxml]"""
import sys
from pathlib import Path

from exporters import CsvExporter, ExcelExporter, WordExporter
from parsers import ArxmlParser, EcuExtractParser, RequirementParser
from pipeline import Pipeline


def main(argv):
    if not argv:
        sys.exit(__doc__)
    comps = ArxmlParser().parse(argv[0])
    reqs = RequirementParser().parse(argv[1]) if len(argv) > 1 else []
    if len(argv) > 2:
        EcuExtractParser.apply(comps, EcuExtractParser().parse(argv[2]))
    result = Pipeline().run(comps, reqs, progress=lambda m, f: print(f"[{f:4.0%}] {m}"))
    out = Path("outputs")
    ExcelExporter().export(result, out / "FuSa_Output.xlsx")
    WordExporter().export(result, out / "FuSa_Output.docx")
    CsvExporter().export(result, out / "csv")
    print(f"Wrote {out.resolve()}")


if __name__ == "__main__":
    main(sys.argv[1:])
